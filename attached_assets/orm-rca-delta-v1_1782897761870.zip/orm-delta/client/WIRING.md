# Client wiring — how to connect the demo HTML to the backend

The `client/index.html` file is the demo copied verbatim. Right now, it renders
from a hardcoded `REVIEWS = [...]` array inside its `<script>` block. Two options
for hooking it to the FastAPI backend:

## Option A — Minimal (recommended for Sprint 1)

Serve the demo as-is, but replace the hardcoded `REVIEWS` array with a fetch
from `/api/reviews`. This is a **~50-line patch** to the script tag.

Find this block near the top of the `<script>` in `client/index.html`:

```js
const REVIEWS = [
  {
    id: 'tp_001',
    type: 'identified',
    author: 'Marcus T.',
    // ... all the mock data
  },
  // ...
];
```

Replace it with:

```js
let REVIEWS = [];         // populated at runtime from backend
let TAXONOMY  = {};       // populated from /api/taxonomy

async function hydrate() {
  try {
    TAXONOMY = await fetch('/api/taxonomy').then(r => r.json());

    // Fetch reviews for the current tab
    const raw = await fetch('/api/reviews').then(r => r.json());
    REVIEWS = raw.map(reviewToDemoShape);

    // Kick the initial render
    if (!state.selected && REVIEWS.length) state.selected = REVIEWS[0].id;
    renderInbox();
    renderReviewCol();
    renderRcaCol();
  } catch (e) {
    console.warn('Backend not reachable, running with static data:', e);
  }
}

function reviewToDemoShape(apiRow) {
  // API list rows are compact — we lazy-load the full RCA when selected.
  return {
    id:         apiRow.id,
    author:     apiRow.author || 'Unknown',
    time:       apiRow.received_at,
    lang:       (apiRow.language || 'en').toUpperCase(),
    tier:       apiRow.match_tier === 1 ? 'T1'
              : apiRow.candidate_state ? 'T2'
              : apiRow.match_tier === 2 ? 'T2'
              : 'UNTR',
    type:       apiRow.match_tier === 1 ? 'identified'
              : apiRow.candidate_state ? 'candidates'
              : 'untraceable',
    status:     apiRow.status || 'new',
    stars:      '★'.repeat(apiRow.rating) + '☆'.repeat(5 - apiRow.rating),
    original:   apiRow.snippet,     // preview only; full body fetched on select
    booking:    { experience: apiRow.experience },
    _lazy:      true,               // marker: hydrate details on click
  };
}

// When user clicks a review, fetch the full record + draft.
async function loadFullReview(id) {
  const detail = await fetch(`/api/reviews/${id}`).then(r => r.json());
  const idx = REVIEWS.findIndex(r => r.id === id);
  if (idx < 0) return;

  const r = detail.review;
  const d = detail.draft || {};

  REVIEWS[idx] = {
    ...REVIEWS[idx],
    _lazy:    false,
    original: r.body_original,
    english:  r.body_english,
    booking:  d.booking,
    matchTier: (d.match_tier === 1) ? 't1' : 't2',
    matchTitle: d.match_tier === 1 ? 'Direct match'
              : d.candidate_state ? 'Possible matches — associate to confirm'
              : 'Match confirmed',
    matchMethod: d.match_method,
    candidateState: d.candidate_state,
    candidatesList: d.candidates_list,
    confidenceTrail: d.confidence_trail,
    events: d.timeline,
    insights: {
      tgidRating:     { value: (d.insights || {}).tgidRating, sub: 'TGID' },
      tidVidRating:   { value: (d.insights || {}).tidVidRating, sub: 'TID·VID' },
      completion:     { value: (d.insights || {}).vidCompletionRate, sub: 'VID', flagToBiz: false },
      sameDayIssues:  { value: (d.insights || {}).sameDaySameVidIssues, sub: 'same VID' },
      similarSupport: d.similar_support,
      similarReviews: d.similar_reviews,
    },
    statedIssue: d.stated_issue,
    rca: {
      issueL1:    d.l1,
      issueL2:    d.l2,
      reasoning:  d.l1_reasoning,
      checks:     d.diagnostic_checks,
      whatWentWrong: (d.what_went_wrong_bullets || []).map(b => '• ' + b).join('\n'),
      supportInteraction: d.support_interaction_frames,
      spInteraction:     d.sp_interaction_frames,
      supportSummary:    d.support_summary,
      areaOfImproving:   (d.area_of_improving || []).map(b => '• ' + b).join('\n'),
      actionsTaken:      d.actions_taken,
      resolution:        d.resolution,
      reply:             d.suggested_response,
    },
  };
  renderReviewCol();
  renderRcaCol();
}
```

Then find the click handler `.review-item` and change it to:

```js
list.querySelectorAll('.review-item').forEach(item => {
  item.addEventListener('click', async () => {
    state.selected = item.dataset.id;
    const r = REVIEWS.find(x => x.id === state.selected);
    if (r && r._lazy) await loadFullReview(state.selected);
    else {
      renderReviewCol();
      renderRcaCol();
    }
    renderInbox();
  });
});
```

Then at the very end of the script, replace `renderInbox(); renderReviewCol(); renderRcaCol();`
with just `hydrate();`.

## Option B — Full rewrite

Rewrite the client as a proper React app that reads/writes the API directly.
Bigger lift, better maintenance. Do this **after** Sprint 1 lands and stakeholders
sign off on the shape.

## API endpoints the demo already knows about

The demo will call these when hooked up:

- `GET  /api/taxonomy` — L1, L2 options, diagnostic checks per L1
- `GET  /api/reviews?tab=bid|possible_matches|untraceable|sent` — inbox rows
- `GET  /api/reviews/{id}` — full review + draft
- `PATCH /api/reviews/{id}/draft-v2` — save any structured edit
- `POST /api/reviews/{id}/select-candidate` — associate picks a Tier 2 candidate
- `POST /api/reviews/{id}/connect-dss` — pull DSS on demand
- `POST /api/reviews/{id}/flag-to-biz` — two-step: draft (no `send`) then send (`send: true`)
- `PATCH /api/reviews/{id}/action` — add/edit/delete an action row
- `POST /api/reviews/{id}/send` — post RCA to Slack thread, send response

## Edit-in-place → PATCH mapping

Wire each editable region to autosave with debounce (~700 ms):

| Editable region       | Call                                                 |
| --------------------- | ---------------------------------------------------- |
| AI RCA heading        | (no persist — cosmetic)                              |
| Stated Issue          | `PATCH /draft-v2 { stated_issue }`                   |
| L1 / L2 dropdowns     | `PATCH /draft-v2 { l1, l2 }`                         |
| L1 reasoning          | `PATCH /draft-v2 { l1_reasoning }`                   |
| Diagnostic check row  | `PATCH /draft-v2 { diagnostic_checks: [...] }`       |
| What Went Wrong       | `PATCH /draft-v2 { what_went_wrong_bullets: [...] }` |
| Support frame edits   | `PATCH /draft-v2 { support_interaction_frames }`     |
| SP frame edits        | `PATCH /draft-v2 { sp_interaction_frames }`          |
| Support summary       | `PATCH /draft-v2 { support_summary }`                |
| Area of Improvement   | `PATCH /draft-v2 { area_of_improving }`              |
| Action Add / Del / Edit | `PATCH /action { tab, op, index?, action? }`       |
| Resolution textarea   | `PATCH /draft-v2 { resolution }`                     |
| Response textarea     | `PATCH /draft-v2 { final_response }`                 |
| Send button           | `POST /send`                                         |
| Connect DSS button    | `POST /connect-dss`                                  |
| Flag to Biz open      | `POST /flag-to-biz { }` (returns draft)              |
| Flag to Biz send      | `POST /flag-to-biz { message, channel, tag, send:true }` |
| Confirm candidate     | `POST /select-candidate { bid }`                     |
