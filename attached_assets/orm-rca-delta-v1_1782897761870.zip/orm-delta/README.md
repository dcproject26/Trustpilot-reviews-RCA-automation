# ORM RCA — Delta Package v1

This is the delta between the existing Replit build (`headout-orm-rca.zip`) and
the demo (`orm-rca-stakeholder-demo-v15.html`). Everything in the demo that is
NOT already in the Replit build is captured here.

## What's already in the existing zip (no changes needed)

- FastAPI + Postgres skeleton
- Slack ingestion webhook + thread post-back
- Tier 1 BID regex + Tier 2 fuzzy booking match
- Zendesk timeline fetch + comment extraction
- Insights fetch from BigQuery
- DSS webhook call
- Translation via Claude
- Basic RCA generation via Claude
- Response draft via Claude with canned-response tone guide
- 3 mock reviews, mock bookings, mock timelines
- Reporting endpoint
- MOCK_MODE fallback for every service

## What's NEW in this delta (build on top of existing)

### Data model changes
- New RcaDraft fields: `rca_fields_v2` (the structured demo output), `resolution`,
  `flag_to_biz_state`, `dss_connected_at`, `stated_issue`, `l1`, `l2`,
  `diagnostic_checks`, `what_went_wrong_bullets`, `support_interaction_frames`,
  `sp_interaction_frames`, `area_of_improving`, `actions_taken`,
  `similar_support`, `similar_reviews`, `candidates_list`, `confidence_trail`

### RCA logic upgrades
- New Claude prompt that outputs the demo's structured schema:
  - Stated Issue (one-line summary)
  - L1 + L2 classification (constrained to taxonomy)
  - Diagnostic checks (Q/A format, one row per check)
  - What Went Wrong (bullet points)
  - Support Interaction frames (guest said / we did / guest reply per thread)
  - SP Interaction frames (separate section)
  - Area of Improvement (only things WE raise)
  - Actions Taken (per team)
  - Similar complaints (split: support tickets + Trustpilot reviews)
- Signal extraction step for Tier 2 candidates
- Candidate picker persistence (top N BigQuery matches with confidence scores)

### New endpoints
- `POST /api/reviews/{id}/select-candidate` — confirm which candidate to use
- `POST /api/reviews/{id}/connect-dss` — pull DSS recommendation on demand
- `POST /api/reviews/{id}/flag-to-biz` — draft + send Slack flag with editable message
- `PATCH /api/reviews/{id}/action` — add/edit/delete individual action taken items
- `GET /api/reviews/{id}/similar` — fetch similar complaints (support + reviews)

### Dashboard (client) refresh
- Replace `client/index.html` with the demo layout (three-column, editable everywhere)

## How to apply

1. Drop each file in this zip at its indicated path
2. Run the DB migration in `migrations/001_add_rca_v2_fields.sql`
3. Restart the Repl
4. Test with a MOCK_MODE review — should render the full demo layout

## What still needs stakeholder input (blockers for Sprint 1)

See `WHAT_YOU_STILL_NEED.md` for the P0/P1/P2 breakdown by stakeholder.
