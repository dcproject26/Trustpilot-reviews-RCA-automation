# WHAT YOU STILL NEED — Sprint 1 blockers

The delta package builds the code. But the system needs stakeholder inputs to actually
run on real data. Ordered by which unblocks which sprint.

## P0 — Sprint 1 blockers (Flow 1: BID-identified reviews end-to-end)

### From you (CX Lead)

1. **L1 / L2 taxonomy catalogue** — replace placeholder lists in `server/taxonomy.py`
   - Full list of L1 categories
   - Every L2 under each L1
   - Format: sheet or JSON (I can convert)

2. **Diagnostic checks per L1** — same file, `DIAGNOSTIC_CHECKS` dict
   - For each L1, the yes/no checks Claude should run
   - Each check needs: key (unique id), question (English), data_source hint
   - The data_source tells Claude where to look — timeline field, booking field, etc.

3. **Support Interaction gap taxonomy** — same file, `GAP_TAXONOMY` list
   - Labelled gap types (e.g. "Minded AI wrong canned response", "CE delay")
   - Used to tag issues in support frames consistently

4. **Signal extraction fields** — confirm the list in `SIGNAL_FIELDS`
   - Currently: guest_name, experience_hint, venue_or_city, visit_date_hint, group_size, issue_summary
   - Confirm or add

5. **Team routing table** — `ACTION_TABS` handles
   - Real Slack handles per Action Taken tab (SP / Customer / Business / Product / CE)

6. **Similar complaints rule** — `SIMILAR_MATCH_RULE`
   - Match on TID+VID? Also require same L1? Window of days?

7. **Response tone / template library**
   - Existing canned responses (if any) — link to the Sheet
   - Or 3-5 sample past responses to seed the tone

### From IT / Slack admin

8. **Slack app credentials** — set as Replit secrets:
   - `SLACK_SIGNING_SECRET`
   - `SLACK_BOT_TOKEN`
   - `SLACK_USER_TOKEN`
   - `SLACK_CHANNEL_ORM` (channel ID, not name)
   - `SLACK_CHANNEL_ALERT` (channel ID)

9. **Trustpilot bot user ID** (optional but improves ingestion):
   - `TRUSTPILOT_BOT_USER_ID` — if set, only messages from this user are treated as reviews.
     Without it, we fall back to detecting star-rating symbols in the message text.

### From Data Team

10. **GCP service account JSON** — set as Replit secret:
    - `GCP_SERVICE_ACCOUNT_JSON` (paste the whole JSON as the value)
    - Confirmed BQ access to `fct_bookings`, `fct_reviews`, `fct_fulfilments`

## P1 — Sprint 2 blockers (Flow 2: Possible-matches candidates)

### From Data Team

11. **Fuzzy match SQL + confidence formula**
    - Weights per field (name / experience / date / venue)
    - Threshold above which we auto-match vs. show picker
    - Name normalisation rules (accents, casing, initials)

12. **Field-to-source mapping**
    - Sheet mapping each dashboard field to a BigQuery column:
      TID name / Fulfilment type / Vendor vs. Supply Partner Name / Booking status enum / Lead time

### From Zendesk Admin

13. **Zendesk credentials**:
    - `ZENDESK_EMAIL`
    - `ZENDESK_API_TOKEN`
    - `ZENDESK_BOOKING_FIELD_ID` (currently defaulted to `360021524471` — confirm)
    - Brand IDs if guest and SP tickets sit under different brands
    - Tag/status convention distinguishing chat / email / call tickets

## P2 — Later sprints

### From DSS Owner

14. **DSS webhook**:
    - `DSS_WEBHOOK_URL`
    - Confirm request payload shape (currently sends: booking_id, tgid, tid, vid, amount, l1, l2)
    - Confirm response payload shape (currently expects: policy, compensation, coverage, action, escalateTo)

### From CX Ops / IT

15. **Trustpilot Slack integration reply mechanism**
    - How does replying to a Trustpilot review actually work? In-thread reply?
      A specific format the integration expects?

## How to add each input

### Taxonomy (items 1-6)
Edit `server/taxonomy.py` directly. Push changes to Replit. Restart. Done.
The API + prompts read these dicts dynamically.

### Credentials (items 8, 10, 13, 14)
In Replit → Secrets pane → add each key/value. Restart. Done.
The `is_live()` checks in `server/config.py` automatically switch from mock to live
per service, so you can wire integrations one at a time without breaking the others.

### Data / SQL (items 11, 12)
Send me the sheet/doc. I'll wire into `server/services/bigquery.py`.

### Sheet-based configs (items 7, 15)
Either share the Sheet ID (set `CANNED_RESPONSES_SHEET_ID` secret) or paste the
content — I'll drop it into `EMBEDDED_CANNED` in prompts.py.

## Sprint 1 kickoff — minimum viable set

If you get **items 1, 2, 8, and 10** to me, I can run the full Flow 1
end-to-end on real reviews in mock mode → live within a day.
