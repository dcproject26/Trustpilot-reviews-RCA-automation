# ORM RCA — Delta v2 (Task #3)

Builds on top of Delta v1 (which is already live on your Repl).

## What's new in v2

- **Full L1 / L2 taxonomy** from CX Lead, with priority order rules baked into the prompt
- **Three sub-theme frameworks**: Meeting Point, Ticket Issues, Audio Guide, Supply Partner
  (frameworks for Customer Support, Content/Misleading, Venue Related etc. still pending)
- **One-call classification**: L1 + L2 + sub-theme in a single Claude call
  (not 3 separate agents — see the architecture note)
- **Validators + graceful fallback**: hallucinated L1/L2/sub_theme is caught and either
  salvaged (code-prefix fuzzy match) or dropped cleanly. Pipeline never breaks on bad
  classification output.
- **BID regex widened** to `\b\d{7,12}\b` (was strict 8-digit). Angela's 11-digit BID
  now matches. Confirm with CX/Data team that this is the right range.
- **Accuracy test harness**: 14 golden reviews with expected L1/L2/sub_theme. Runs on
  every PR to catch regressions.
- **Validator unit tests**: proves the resilience layer catches hallucinations without
  breaking downstream steps.

## Files in this delta

```
orm-delta-v2/
├── README.md                                — this file
├── CONNECTORS.md                            — full connector inventory (what you need)
├── server/
│   ├── taxonomy.py                          — REPLACES v1 version, adds sub-themes + validators
│   ├── prompts.py                           — REPLACES v1 version, one-call classification prompt
│   └── services/
│       └── classifier.py                    — NEW — validators + graceful fallback
└── tests/
    ├── test_classification_accuracy.py      — 14 golden reviews, mock + live modes
    └── test_classifier_validators.py        — 23 unit tests for the validation layer
```

## How to apply

1. Copy the delta files into the Repl at the same paths
2. No DB migration needed (this is all in-memory taxonomy + prompt changes)
3. Update `pipeline.py` step 11 to use the new classifier:
   ```python
   # OLD:
   cls = await claude.classify(review_text, booking, timeline, review_id)

   # NEW:
   from server.services.classifier import classify
   from server.services.claude import _call as claude_call
   result = await classify(review_text, booking, timeline, claude_call, review_id)
   l1, l2, sub_theme = result.l1, result.l2, result.sub_theme
   ```
4. Add `sub_theme` column to the `rca_drafts` table:
   ```sql
   ALTER TABLE rca_drafts ADD COLUMN IF NOT EXISTS sub_theme TEXT;
   ```
   And add `sub_theme = Column(String, nullable=True)` in `server/db.py::RcaDraft`.
5. Restart the Repl.
6. Run the tests locally to confirm plumbing:
   ```bash
   python -m tests.test_classifier_validators   # 23 passed
   python -m tests.test_classification_accuracy # 14/14 with mock; try REAL_CLAUDE=1
   ```

## How to test with real Claude

The mock test proves plumbing. To measure actual model accuracy on real Claude output:

```bash
export REAL_CLAUDE=1
export ANTHROPIC_API_KEY=<your-key>
python -m tests.test_classification_accuracy
```

Expect the accuracy to NOT be 100% on real Claude — that's the point. The mock hits 100%
because it hands back exactly what the golden set expects. Real Claude gets tested against
the same golden set, and any misclassifications tell you where to tighten the prompt.

## Adding more sub-theme frameworks later

When CX Lead sends you a new sub-theme framework (e.g. for Customer Support Issues):

1. Add a new dict to `server/taxonomy.py` following the MP_SUB_THEMES pattern
2. Register it in `SUB_THEME_REGISTRY` at the bottom
3. Add golden test rows to `tests/test_classification_accuracy.py::GOLDEN`
4. Run the tests
5. Restart the Repl

Zero prompt changes needed — the prompt reads from the registry.

## Architecture decision recorded

**Single-flow classification, not multi-agent.** Rationale:

- L1 → L2 → sub_theme are the same task at three granularities, needing the same context
- Multi-agent would 3-4× the latency and cost with no accuracy benefit
- The resilience concern (one step failing) is solved by validators + try/except at the
  pipeline level, not by call splitting
- Steps that DO benefit from independence (Translation, Classification, RCA, Response)
  are already separate calls — that's the right split
- Full argument in transcripts, but bottom line: independence at the pipeline level,
  not the agent level, gives you the resilience without the cost

## Sub-theme framework coverage status

Frameworks received and implemented:
- Meeting Point Issues ✓
- Ticket Issues ✓
- Audio Guide Issues ✓
- Supply Partner Issue (covers Guide No Show, Guide Left, Guide Behaviour, Guide Timing,
  Guide Quality, Contact Issue, Other SP) ✓

Frameworks still pending (5 golden reviews are waiting on Customer Support framework):
- Customer Support Issues
- Content - Instructions not clear / Misleading Info
- Customer expectation mismatch
- Inventory Listing Issue
- Venue Related sub-themes
- External Factor sub-themes
- Miscellaneous Issue sub-themes

When each arrives, follow the "Adding more sub-theme frameworks later" section above.
