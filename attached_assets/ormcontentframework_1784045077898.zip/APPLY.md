# Apply — Content sub-theme framework (the ONLY change vs your live app)

Your live Replit app is already ahead of the earlier handoff: pipeline wiring,
the widened BID regex, the `sub_theme` DB column, migration 002, and the newer
array-handling classifier are **already live**. Do **not** re-upload a full
package — it would regress those.

**The only thing missing on live is the Content sub-theme framework.** This
delta adds it, and nothing else.

## What changed
`server/taxonomy.py` only — a pure addition (0 lines removed, ~57 added):
- `CONTENT_SUB_THEMES` (13 text themes A–M + `N. Irrelevant`)
- one registry entry: `("Operations Issue", "Content - Instructions not clear / Misleading Info")`

## Apply it — pick ONE

**Option A — replace the file** (simplest): drop `server/taxonomy.py` from this
zip into the Repl at the same path. It's your live `taxonomy.py` with only the
Content block added; everything else is byte-identical.

**Option B — apply the patch** (if you have local edits to preserve):
```bash
git apply content-framework.patch        # or: patch -p1 < content-framework.patch
```

Then restart the Repl. No DB change, no pipeline change, no secrets change.

## Verify
```bash
python -m tests.test_classifier_validators     # 23 passed
python -m tests.test_classification_accuracy   # 14/14 (mock)
```

## Note
Content classifies from review text alone (like MP/SP/Ticket/AG). Two themes —
E "Missing FAQ/KBYG" vs F "Misleading FAQ/KBYG" — can blur without the BigQuery
content metadata; 11 of 13 classify cleanly. See the comment block in
`taxonomy.py` for detail.
