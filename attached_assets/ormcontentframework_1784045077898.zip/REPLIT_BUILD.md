# REPLIT_BUILD.md — corrected after seeing the live app

**Superseded plan note:** an earlier version of this guide described uploading a
multi-file package (pipeline.py, db.py, classifier.py, migration). After
receiving the actual live Replit files (`ormrcav2changedfiles.zip`), that is
**wrong and would regress the live app.** The live app is already ahead:

| File | Live state |
|------|-----------|
| `pipeline.py` | already wired to `classify_v2`, uses widened `BID_REGEX`, persists `sub_theme` |
| `db.py` | `RcaDraft.sub_theme` column present |
| `migrations/002_add_sub_theme.sql` | present |
| `services/classifier.py` | newer than the handoff — handles JSON arrays / non-dict output |
| `taxonomy.py` | MP/SP/Ticket/AG frameworks present — **Content missing** |

## The only change vs live: the Content framework

This repo now **mirrors the live app** for every file it shipped, plus one
addition: the **Content sub-theme framework** in `server/taxonomy.py`
(0 lines removed from live, ~57 added).

- `CONTENT_SUB_THEMES` — 13 text themes A–M + `N. Irrelevant`
- registry entry for `("Operations Issue", "Content - Instructions not clear / Misleading Info")`

## Apply (pick one)

- **Replace** `server/taxonomy.py` on the Repl with this repo's version (it's live
  + Content, otherwise byte-identical), **or**
- **Apply the patch**: `git apply content-framework.patch`

Then restart. No DB change, no pipeline change, no secrets change. See
`deliverable/APPLY.md` for the packaged version of these steps.

## Verify
```bash
python -m tests.test_classifier_validators     # 23 passed
python -m tests.test_classification_accuracy   # 14/14 (mock)
```

## Connectors (unchanged — see CONNECTORS.md)
Runtime AI is **Replit AI Integrations** (no raw key). Priority secrets:
Anthropic (via Integrations) → Slack → BigQuery → Zendesk → DSS → canned responses.

## Still open
- **Real accuracy unmeasured** — run `REAL_CLAUDE=1 python -m tests.test_classification_accuracy`
  on the Repl (uses Replit AI). Note: now that Content has a framework, reviews
  classified as Content L2 will expect a sub_theme — worth watching in that run.
- **Content E vs F** blur without BigQuery content metadata (11/13 clean).
- Frameworks still owed by CX (Customer Support, Venue, External Factor, Misc).
