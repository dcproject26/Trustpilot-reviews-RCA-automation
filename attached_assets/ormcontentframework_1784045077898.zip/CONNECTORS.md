# Connectors — full inventory

This is what you need to make the RCA system actually run on real data, not mock.

Each section says: **what the connector does, what the system needs from you, and
what to ask the stakeholder for**. Ordered by which unblocks which sprint.

Set everything as Replit Secrets — the code reads via `os.getenv()` and the `is_live()`
gate in `server/config.py` automatically switches from mock to live per-service.

---

## Sprint 1 unblockers (do these first)

### 1. Slack (inbound review ingestion + outbound RCA post-back)

**What it does:** Catches Trustpilot reviews posted to `#team-orm-online-reputation`
and `#alert-customerlove` via Slack Events API. Also posts the internal RCA summary
back to the review thread when the associate hits Send.

**Ask IT / Slack admin for:**
- Slack app created in the Headout workspace, name it "ORM RCA Assistant"
- Bot scopes needed: `chat:write`, `channels:history`, `chat:write.public`,
  `groups:history`, `im:history`
- User scope needed: `chat:write` (needed for posting as CE, not as the bot)
- Signing secret
- Bot token (starts `xoxb-`)
- User token (starts `xoxp-`)
- Channel IDs for `#team-orm-online-reputation` and `#alert-customerlove` (right-click
  channel → View channel details → Channel ID at the bottom)
- Trustpilot bot user ID if there is one (right-click on the bot's name in Slack →
  View profile → look for a `U…` ID)

**Set as Replit Secrets:**
```
SLACK_SIGNING_SECRET       = <from Slack app settings > Basic Information>
SLACK_BOT_TOKEN            = xoxb-...
SLACK_USER_TOKEN           = xoxp-...
SLACK_CHANNEL_ORM          = C… (channel ID)
SLACK_CHANNEL_ALERT        = C… (channel ID)
TRUSTPILOT_BOT_USER_ID     = U… (optional, improves ingestion accuracy)
```

**Also configure in the Slack app UI:**
- Event Subscriptions → Request URL: `https://<your-repl>.replit.app/webhook/slack`
- Subscribe to bot events: `message.channels`, `message.groups`

**How to test it's working:**
Post any test message in one of the two channels. The Repl should log
`[webhook] Received event: message.channels`. If it doesn't, the URL isn't
reachable or the token doesn't have `channels:history`.

---

### 2. BigQuery (booking match, insights, similar complaints)

**What it does:** Tier 1 lookup of a booking by BID. Tier 2 fuzzy match by
guest name + experience + date when no BID. Fetches TGID rating, TID-VID rating,
completion %, same-day same-VID issues. Fetches similar historic reviews and tickets.

**Ask Data Team for:**

**Access (read-only):**
- GCP service account with `bigquery.dataViewer` role on:
  - `headout-analytics.analytics_reporting.fct_bookings`
  - `headout-analytics.analytics_reporting.fct_reviews`
  - `headout-analytics.analytics_reporting.fct_fulfilments`
- Send the JSON key file privately

**Reusable SQL:** the existing Looker queries for these four metrics — I'd rather
reuse than rewrite:
1. TGID average rating (last 4 weeks)
2. TID-VID average rating (last 4 weeks) + percentage negative
3. VID Booking Completion Rate
4. Same-day same-VID issues count

**Field mapping — confirm column names:**
| Dashboard field | Which BigQuery column? |
|---|---|
| TID name | ? |
| Fulfilment type | ? |
| Vendor ID | ? |
| Supply Partner Name (is this same as Vendor?) | ? |
| Booking status enum values | full list please |
| Lead time | stored or computed? |

**Fuzzy match:**
- Confidence formula and weights per field (name / experience / date / venue)
- Threshold above which we auto-match vs. show the associate a picker
- Name normalisation rules (accents, casing, initials)

**Set as Replit Secrets:**
```
GCP_SERVICE_ACCOUNT_JSON       = <paste the entire JSON blob>
BIGQUERY_BOOKINGS_TABLE        = headout-analytics.analytics_reporting.fct_bookings
BIGQUERY_REVIEWS_TABLE         = headout-analytics.analytics_reporting.fct_reviews
BIGQUERY_FULFILMENTS_TABLE     = headout-analytics.analytics_reporting.fct_fulfilments
```

**How to test:** with `GCP_SERVICE_ACCOUNT_JSON` set, restart the Repl. Then post a
Slack message containing a real BID. Check the Repl logs for `[bigquery] Tier 1 match: <BID>`.
If mock data appears instead, either the JSON is malformed or the service account
doesn't have access.

---

## Sprint 2 unblockers

### 3. Zendesk (support timeline)

**What it does:** For a given BID, fetches all Zendesk tickets tagged with that
booking, and returns their comments in chronological order to build the events timeline.
Distinguishes chat / email / call, guest vs. CE vs. SP messages.

**Ask Zendesk admin for:**
- Zendesk agent email
- API token (from Admin Center → Apps and integrations → APIs → Zendesk API)
- The custom field ID that holds the Booking ID (currently defaulted to `360021524471`
  — please confirm)
- Brand IDs — are guest tickets and SP tickets under the same brand or different?
- Tag / status convention distinguishing chat vs. email vs. call tickets

**Set as Replit Secrets:**
```
ZENDESK_SUBDOMAIN         = headout    (from headout.zendesk.com)
ZENDESK_EMAIL             = <agent email>
ZENDESK_API_TOKEN         = <token>
ZENDESK_BOOKING_FIELD_ID  = 360021524471    (confirm this is right)
ZENDESK_BRAND_GUEST       = <brand id>      (if applicable)
ZENDESK_BRAND_SP          = <brand id>      (if applicable)
```

**How to test:** with credentials set, POST to `/api/reviews/manual` with a real BID.
Check the RCA draft — the timeline field should show real Zendesk events, not mocks.

---

### 4. Google Apps Script (Zendesk comment fetch batching)

**What it does:** Zendesk's per-ticket comment endpoint is rate-limited. The existing
Apps Script batches multiple ticket lookups into one call, working around it.

**Already deployed** — the URL is in `config.py`. If it stops working, contact whoever
maintains it (was set up before you took over).

**Set as Replit Secret (optional override):**
```
APPS_SCRIPT_URL = <URL>   (already has a default in config.py)
```

---

## Sprint 3 unblockers

### 5. DSS webhook (Retool policy lookup)

**What it does:** Given a case's L1/L2 and booking info, returns the DSS policy
recommendation (comp amount, coverage, escalation contact). Fires when the associate
clicks "Connect DSS" in the Resolution section, or eagerly during the pipeline.

**Ask DSS Owner for:**
- The Retool webhook URL
- Request payload shape — currently we send:
  ```json
  {"booking_id": "...", "tgid": "...", "tid": "...", "vid": "...",
   "amount": "...", "l1": "...", "l2": "..."}
  ```
  Confirm this is what the webhook expects, or tell us the actual shape.
- Response payload shape — currently we expect:
  ```json
  {"policy": "...", "compensation": "...", "coverage": "...",
   "action": "...", "escalateTo": "..."}
  ```
  Confirm or correct.
- Any auth mechanism (Bearer token? IP allowlist? Header key?)

**Set as Replit Secret:**
```
DSS_WEBHOOK_URL          = <URL>
DSS_WEBHOOK_AUTH_HEADER  = <if any>
```

---

### 6. Canned response library (Google Sheets)

**What it does:** Feeds the response-draft prompt with tone examples so replies match
Headout's voice. Not a template to fill in — a style guide.

**Ask CX Lead for:**
- The Google Sheet ID that holds the canned response library
- Or paste 10-15 example past responses and I'll embed them

**Set as Replit Secret:**
```
CANNED_RESPONSES_SHEET_ID = <sheet id from the URL>
```

**How to test:** with the sheet ID set, restart the Repl. The response draft should
reflect tone from the sheet rather than the embedded fallback.

---

### 7. Anthropic API (Claude)

**What it does:** All the AI calls — translation, signal extraction, classification,
RCA generation, response draft, flag-to-biz message.

**Already handled via Replit AI Integrations** if that's enabled for the Headout org.
Confirm with your Replit admin:

- Go to Repl settings → AI Integrations → check that Anthropic is toggled on
- If yes: no key needed, works automatically
- If no: get an Anthropic API key and set as Replit Secret `ANTHROPIC_API_KEY`

**Optional:**
```
ANTHROPIC_MODEL = claude-sonnet-4-5   (default; can override for tests)
```

---

## Sprint 4+ (later)

### 8. Trustpilot API (for auto-takedowns, not currently used)

Trustpilot API is not currently in the flow. If we want auto-takedown or
auto-review-reply-send later, we'll need OAuth credentials from Trustpilot.

### 9. Reporting sink (in-app or Looker or Sheet)

Currently the `/api/reporting` endpoint returns aggregate metrics. To surface these
for weekly digests we need to decide:
- In-app reporting page (I can build)
- Push metrics to an existing Looker dashboard
- Write to a Google Sheet (like the current weekly Trustpilot digest Apps Script)

Answer this and I'll wire it up.

---

## Summary: what to send to which stakeholder

Copy each of these into a Slack/email:

**To IT / Slack admin:**
> Hi — for the ORM RCA project on Replit, please create a Slack app named "ORM RCA Assistant"
> in the Headout workspace. Bot scopes: `chat:write`, `channels:history`, `chat:write.public`,
> `groups:history`, `im:history`. User scope: `chat:write`. Configure the Events API to POST to
> `https://<my-repl>.replit.app/webhook/slack` with subscriptions to `message.channels` and
> `message.groups`.
>
> Please send me privately: signing secret, bot token, user token, and channel IDs for
> `#team-orm-online-reputation` and `#alert-customerlove`. Also the Trustpilot bot's user ID if
> there is one. Thanks.

**To Data team:**
> Hi — need read-only BigQuery access for the ORM RCA tool on Replit. Please create a service
> account with `bigquery.dataViewer` on:
> - `headout-analytics.analytics_reporting.fct_bookings`
> - `headout-analytics.analytics_reporting.fct_reviews`
> - `headout-analytics.analytics_reporting.fct_fulfilments`
>
> Send the JSON key privately. Also — please share the existing Looker queries for TGID rating,
> TID-VID rating, VID completion rate, and same-day same-VID issues. I'd like to reuse those
> rather than rewrite. And confirm which columns hold TID name, fulfilment type, vendor ID, and
> booking status.
>
> Finally: fuzzy-match scoring — do you have weights per field (name / experience / date) and
> a confidence threshold to auto-match vs. show a picker?

**To Zendesk admin:**
> Hi — need Zendesk API access for the RCA tool. Please send: agent email + API token. Also
> confirm the custom field ID for Booking ID (currently defaulted to 360021524471) and whether
> guest and SP tickets are under the same brand. And the tag/status convention distinguishing
> chat / email / call tickets. Thanks.

**To DSS Owner:**
> Hi — need the Retool DSS webhook URL for the RCA tool. Also please confirm the request
> payload shape (I'm sending `{booking_id, tgid, tid, vid, amount, l1, l2}`) and the response
> shape (I'm expecting `{policy, compensation, coverage, action, escalateTo}`). And any auth
> mechanism (header key, bearer token, IP allowlist).

**To Replit org admin:**
> Hi — please confirm the Anthropic AI Integration is enabled for our Repl workspace.
