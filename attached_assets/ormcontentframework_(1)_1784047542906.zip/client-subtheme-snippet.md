# Add sub-theme to the dashboard — client snippet (drop-in)

The backend is already wired (see `api.py` changes: `_draft_dict` now returns
`sub_theme`, `DraftPatchV2` accepts it, patch loop saves it). This adds the
**Sub-theme row** to the Issue Classification block, taxonomy-driven so it never
duplicates the taxonomy in the frontend.

Applies to the demo-v15 `.classify-block`. **Add — don't replace the file.**

## 1. HTML — add a Sub-theme row right after the L2 `classify-row`

Find the L2 row in the Issue Classification block (ends with the L2 `<select>`),
and insert this **after** it, before the `reasoning-text` div:

```html
        ${(rca.subTheme || (SUB_THEME_OPTIONS[rca.issueL1 + '::' + rca.issueL2] || []).length) ? `
        <div class="classify-row">
          <span class="classify-label">Sub-theme</span>
          <select class="classify-select">
            ${rca.subTheme ? `<option>${rca.subTheme}</option>` : `<option value="">— none —</option>`}
            ${(SUB_THEME_OPTIONS[rca.issueL1 + '::' + rca.issueL2] || [])
                .filter(o => o !== rca.subTheme)
                .map(o => `<option>${o}</option>`).join('')}
          </select>
        </div>` : ''}
```

Behavior: the row only appears when the review has a sub-theme **or** the current
(L1, L2) has a framework. If there's no framework (e.g. an L2 with no sub-themes),
it renders nothing — no empty dropdown.

## 2. JS — the options map (no hardcoding; fills from the taxonomy API)

Next to `const L2_OPTIONS = {…}`, add:

```js
// Keyed "L1::L2" -> ["A. Name", …, "N. Irrelevant"].
// Populated from /api/taxonomy (which already returns `sub_theme_frameworks`
// in exactly this "L1::L2" key form) so the frontend never duplicates taxonomy.
// Empty is safe: the row still shows the classified sub_theme; the editable
// options simply fill in once the taxonomy loads.
const SUB_THEME_OPTIONS = {};

async function loadSubThemeOptions() {
  try {
    const t = await (await fetch('/api/taxonomy')).json();
    const fw = t.sub_theme_frameworks || {};
    for (const key in fw) {
      const f = fw[key];
      const opts = (f.sub_themes || []).map(([code, name]) => `${code}. ${name}`);
      if (f.exclusion_label) opts.push(f.exclusion_label);
      SUB_THEME_OPTIONS[key] = opts;
    }
  } catch (e) { /* leave empty — row still shows the assigned sub_theme */ }
}
// call once on load (await before first render, or re-render after it resolves)
loadSubThemeOptions();
```

## 3. Field mapping — one line to confirm

The API returns `sub_theme` on each draft. Wherever the client maps a draft into
its `rca` view-model (alongside `issueL1`/`issueL2`), add:

```js
subTheme: draft.sub_theme || null,
```

If your view-model uses the raw field name, use `rca.sub_theme` in the HTML
above instead of `rca.subTheme`. That's the only naming choice to verify.

## 4. Saving an edit (optional, matches L1/L2)

The `/api/reviews/{id}/draft-v2` PATCH already accepts `sub_theme`. If your L2
dropdown persists edits, mirror it for the sub-theme select — send
`{ "sub_theme": "<selected value>" }`.

---

**Why a snippet, not a file:** your live `client/index.html` wasn't in what you
sent, and it may be ahead of the handoff copy (the backend was). Dropping these
three additions in is safe; replacing the whole file blind is not. If you send
the live `client/index.html`, I'll apply these directly and hand back the file.
